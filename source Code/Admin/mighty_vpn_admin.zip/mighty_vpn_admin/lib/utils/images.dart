class LanguageImages {
  static const icUs = "";
  static const icIndia = "";
  static const icAr = "";
  static const icJapanese = "";
  static const icKorean = "";
  static const icThai = "";
  static const icVietnamese = "";
}

class AppImages {
  String appIcon = "images/app_logo.png";
  String singingBackground = "images/login_background.jpg";
  String profileImage = 'images/profile.png';
  String changePasswordIcon = 'images/change_password.png';
  String dashBoardAppLogo = 'images/dashboard_app_logo.png';
  String placeholder_image = 'images/placeholder.png';
}
