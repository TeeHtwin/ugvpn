import 'package:flutter/material.dart';

const primaryColor = Color(0xFF005AFF);
const appButtonColor = Color(0xFFe3effe);
const defaultPrimaryColor = primaryColor;
const secondaryColor = Color(0xFF000000);
const scaffoldColorDark = Color(0xFF090909);
const appButtonColorDark = Color(0xFF282828);
const scaffoldSecondaryDark = Color(0xFF1E1E1E);
