import 'package:flutter/material.dart';

class ViewModel {
  Widget?view;
  String?title;
  IconData?icon;

  ViewModel({this.view,this.title,this.icon});
}
